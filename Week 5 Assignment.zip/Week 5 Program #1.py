def is_equilateral_triangle(a, b, c):
    if a == b and b == c:
        return True
    else:
        return False

# Accept input from the user
side_a = float(input("Enter the length of side A: "))
side_b = float(input("Enter the length of side B: "))
side_c = float(input("Enter the length of side C: "))

# Check if the triangle is equilateral
if is_equilateral_triangle(side_a, side_b, side_c):
    print("The triangle is equilateral.")
else:
    print("The triangle is not equilateral.")
