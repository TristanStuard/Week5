def calculate_payment_schedule(purchase_price, rate, monthly_payment):
    remaining_balance = purchase_price
    month = 1

    print("Month\tBalance\t\tInterest\tPrincipal\tPayment\t\tRemaining Balance")
    print("-----------------------------------------------------------------------------")

    while remaining_balance > 0:
        interest = remaining_balance * rate / 12
        principal = monthly_payment - interest
        remaining_balance -= principal

        print(f"{month}\t{remaining_balance:.2f}\t\t{interest:.2f}\t\t{principal:.2f}\t\t{monthly_payment:.2f}\t\t{remaining_balance:.2f}")

        month += 1

    print("-----------------------------------------------------------------------------")

# Accept input from the user
purchase_price = float(input("Enter the purchase price: $"))
rate = float(input("Enter the interest rate (in decimal form): "))
monthly_payment = float(input("Enter the monthly payment amount: $"))

# Calculate and display the payment schedule
calculate_payment_schedule(purchase_price, rate, monthly_payment)
