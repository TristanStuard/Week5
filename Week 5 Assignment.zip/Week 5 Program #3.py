import random
import math

smaller = int(input("Enter the smaller number: "))
larger = int(input("Enter the larger number: "))

min_guesses = math.ceil(math.log(larger - smaller + 1, 2))
print("Think of a number between", smaller, "and", larger)
print("The computer will try to guess it in", min_guesses, "guesses or less.")

count = 0
low = smaller
high = larger

while count < min_guesses:
    count += 1
    guess = random.randint(low, high)
    print("Guessing:", guess)
    response = input("Enter 's' if the guess is too small, 'l' if it's too large, or 'c' if it's correct: ")
    
    if response == 's':
        low = guess + 1
    elif response == 'l':
        high = guess - 1
    elif response == 'c':
        print("Congratulations! The computer guessed your number in", count, "tries!")
        break
    else:
        print("Invalid input. Please enter 's', 'l', or 'c'.")

    if count == min_guesses:
        print("The computer couldn't guess your number within the minimum number of guesses. You win!")
