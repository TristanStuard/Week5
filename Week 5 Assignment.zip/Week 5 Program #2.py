def is_right_triangle(a, b, c):
    sides = [a, b, c]
    sides.sort()
    if sides[2] ** 2 == sides[0] ** 2 + sides[1] ** 2:
        return True
    else:
        return False

# Accept input from the user
side_a = float(input("Enter the length of side A: "))
side_b = float(input("Enter the length of side B: "))
side_c = float(input("Enter the length of side C: "))

# Check if the triangle is a right triangle
if is_right_triangle(side_a, side_b, side_c):
    print("The triangle is a right triangle.")
else:
    print("The triangle is not a right triangle.")
